# RY_RENT
A fully configurable and customizable vehicle rental system.

![alt text](https://imgur.com/Ft2y0L3.png)
 
**IMPORTANT**

- Change the name of the folder to ry_rent or it won't work
- For best usage please use 310x250 Pixels in images.
- Do not use this script to make money, if you use it for personal use, please give the credits.
