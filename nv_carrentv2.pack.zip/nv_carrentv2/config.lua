Config = {}

function Notify(message)
    exports['nvNotification']:Show({sound = 'not1',icon = 'fas fa-exclamation-circle text-danger',title = 'Nastala chyba',message = message ,time = 7000,appname = 'Server'})
end

Config.Carrentlocations = {
    Carrent1 = {
        coords = vector3(110.0764, -1089.3026, 29.3025),
        carspawn = vector4(111.0363, -1080.8760, 29.1924, 359.4228)
    },
    Carrent2 = {
        coords = vector3(-49.8681, -1113.5405, 26.4342),
        carspawn = vector4(-51.2663, -1114.1844, 26.4362, 359.4228)
    }
}
Config.Cars = {
    'adder',
    'adder',
    'adder',
    'adder'
}

Config.price = { ---per min
    200,
    400,
    800,
    1600
}


-- 10 or higher!
Config.mindestlaufzeit = 10 --Minimum to rent in min

Config.platetext = "nvscripts"

--Notifications
Config.Notification1 = "10 minutes left until the end of the car rental!"
Config.Notification2 = "1 min left until the end of the car rental!"
Config.Notification5 = "The rent has expired!"
Config.Notification6 = "You don't have enough money!"
Config.Notification7 = "The minimum rental period is 10 minutes"
Config.Notification8 = "You have already rented 1 car!"
Config.helpnotify = "Press ~INPUT_CONTEXT~ to rent a car!"

--Blip
Config.blipon = true
Config.Blip = {
	Blip = {
        Coord = vector3(109.8588, -1089.8578, 29.3025),
        Name = "Carrent",
        Sprite = 523,
        Scale = 1.0,
        Colour = 3,
    }
}